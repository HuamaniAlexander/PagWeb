package diseñopatrones;
//SRP - se encarga de enviar mensaje solo por push
//LSP - esta clase puede sustituir a cualquier otra que implemente CanalNotificacion
public class CanalPush implements CanalNotificacion {
    @Override
    public void enviar(String contenido) {
        System.out.println("Push enviado - " + contenido);
    }
}
