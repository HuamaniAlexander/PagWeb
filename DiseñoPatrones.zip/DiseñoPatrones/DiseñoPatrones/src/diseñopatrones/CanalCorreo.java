package diseñopatrones;
//SRP - se encarga de enviar mensaje solo por correo
//LSP - esta clase puede sustituir a cualquier otra que implemente CanalNotificacion
public class CanalCorreo implements CanalNotificacion {
    @Override
    public void enviar(String contenido) {
        System.out.println("Correo enviado - " + contenido);
    }
}