package diseñopatrones;
//OCP - permite agregar nuevos tipos de mensaje sin modificar el sistema
//ISP - esta interfaz es especifica ya que solo define el metodo necesario para obtener el contenido del mensaje
public interface TipoMensaje {
    String obtenerContenido();
}
