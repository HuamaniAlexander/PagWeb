package diseñopatrones;
//SRP - solo define el contenido de un recordatorio
//LSP - esta clase puede sustituir a cualquier otra que implemente TipoMensaje
public class MensajeRecordatorio implements TipoMensaje {
    @Override
    public String obtenerContenido() {
        return "RECORDATORIO: Recuerda tu cita pendiente";
    }
}