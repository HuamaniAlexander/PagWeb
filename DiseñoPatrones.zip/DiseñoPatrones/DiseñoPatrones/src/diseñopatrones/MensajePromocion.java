package diseñopatrones;
//SRP - solo define el contenido de una promocion
//LSP - esta clase puede sustituir a cualquier otra que implemente TipoMensaje
public class MensajePromocion implements TipoMensaje {
    @Override
    public String obtenerContenido() {
        return "PROMOCION: Oferta con descuento especial";
    }
}