package diseñopatrones;
//SRP - solo define el contenido de un mensaje urgente
//LSP - esta clase puede sustituir a cualquier otra que implemente TipoMensaje
public class MensajeAlerta implements TipoMensaje {
    @Override
    public String obtenerContenido() {
        return "ALERTA: Este es un mensaje urgente";
    }
}