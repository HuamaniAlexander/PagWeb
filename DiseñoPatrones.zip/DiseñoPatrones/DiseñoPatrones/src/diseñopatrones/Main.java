package diseñopatrones;

public class Main {
    public static void main(String[] args) {
        
        GestorNotificaciones not1 = new GestorNotificaciones(new CanalCorreo(), new MensajeAlerta());
        GestorNotificaciones not2 = new GestorNotificaciones(new CanalSMS(), new MensajeAlerta());
        GestorNotificaciones not3 = new GestorNotificaciones(new CanalPush(), new MensajeAlerta());
        
        not1.enviar();
        not2.enviar();
        not3.enviar();
        System.out.println("");
        
        GestorNotificaciones not4 = new GestorNotificaciones(new CanalCorreo(), new MensajePromocion());
        GestorNotificaciones not5 = new GestorNotificaciones(new CanalSMS(), new MensajePromocion());
        GestorNotificaciones not6 = new GestorNotificaciones(new CanalPush(), new MensajePromocion());
        not5.enviar();
        not4.enviar();
        not6.enviar();
        System.out.println("");

        GestorNotificaciones not7 = new GestorNotificaciones(new CanalCorreo(), new MensajeRecordatorio());
        GestorNotificaciones not8 = new GestorNotificaciones(new CanalSMS(), new MensajeRecordatorio());
        GestorNotificaciones not9 = new GestorNotificaciones(new CanalPush(), new MensajeRecordatorio());
        not8.enviar();
        not7.enviar();
        not9.enviar();
    }
}

