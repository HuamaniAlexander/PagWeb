package diseñopatrones;
//OCP - permite agregar nuevos canales sin modificar el sistema
//ISP - esta interfaz es especifica ya que solo define el metodo necesario para enviar mensajes
public interface CanalNotificacion {
    void enviar(String contenido);
}
