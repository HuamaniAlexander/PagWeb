package Ejercicio01;

public class Ejercicio01 {
    public static long f(long n) {
        return n * n * n + 3 * n + 1;
    }

    public static void main(String[] args) {
        long tiempoInicial = System.currentTimeMillis();
        long result = f(10);
        System.out.println("El resultado es: " + result);
        long tiempoFinal = System.currentTimeMillis();
        long tiempoTranscurrido = tiempoFinal - tiempoInicial;
        double tiempoTranscurridoSegundos = (double) tiempoTranscurrido / 1000.0;
        System.out.println("Tiempo total de ejecucion: " + tiempoTranscurridoSegundos + "s");
    }
}