package Ejercicio03;

public class Ejercicio03 {
    public static double f(double n) {
        //Polinomio de grado O(n^k) -> 2(n^3)
        return (2 * (n * n * n)) + (2 * (n * n)) + n;
    }

    public static void main(String[] args) {
        long tiempoInicial = System.currentTimeMillis();
        double result = f(10);
        System.out.println("El resultado es: " + result);
        long tiempoFinal = System.currentTimeMillis();
        long tiempoTranscurrido = tiempoFinal - tiempoInicial;
        double tiempoTranscurridoSegundos = (double) tiempoTranscurrido / 1000.0;
        System.out.println("Tiempo total de ejecucion: " + tiempoTranscurridoSegundos + "s");
    }
}
