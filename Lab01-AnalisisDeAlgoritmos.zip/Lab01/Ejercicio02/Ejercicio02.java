package Ejercicio02;

public class Ejercicio02 {
    public static double f(double n) {
        return 0.5 * n * n + (0.5 * n);
    }

    public static void main(String[] args) {
        long tiempoInicial = System.currentTimeMillis();
        double result = f(10);
        System.out.println("El resultado es: " + result);
        long tiempoFinal = System.currentTimeMillis();
        long tiempoTranscurrido = tiempoFinal - tiempoInicial;
        double tiempoTranscurridoSegundos = (double) tiempoTranscurrido / 1000.0;
        System.out.println("Tiempo total de ejecucion: " + tiempoTranscurridoSegundos + "s");
    }
}
