package diseñopatrones;
// DIP - depende de las interfaces CanalNotificacion y TipoMensaje, no de clases concretas
public class GestorNotificaciones {
    private final CanalNotificacion canal;
    private final TipoMensaje tipo;

    public GestorNotificaciones(CanalNotificacion canal, TipoMensaje tipo) {
        this.canal = canal;
        this.tipo = tipo;
    }

    public void enviar() {
        String contenido = tipo.obtenerContenido();
        canal.enviar(contenido);
    }
}