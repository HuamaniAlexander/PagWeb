package diseñopatrones;
//SRP - se encarga de enviar mensaje solo por SMS
//LSP - esta clase puede sustituir a cualquier otra que implemente CanalNotificacion
public class CanalSMS implements CanalNotificacion {
    @Override
    public void enviar(String contenido) {
        System.out.println("SMS enviado - " + contenido);
    }
}